const { chromium } = require('playwright');

const URL = process.env.GAME_URL || 'http://127.0.0.1:4173/flail-dev/';
const ITERATIONS = 5;
const results = [];

(async () => {
  const browser = await chromium.launch({ args: ['--no-sandbox'], headless: true });

  async function runTest(label, viewport) {
    const ctx = await browser.newContext({ viewport });
    const page = await ctx.newPage();
    const logs = [];
    const errors = [];
    page.on('console', m => logs.push(`[${m.type()}] ${m.text().slice(0,200)}`));
    page.on('pageerror', e => errors.push(String(e).slice(0,300)));

    await page.goto(URL, { waitUntil: 'networkidle', timeout: 30000 }).catch(e => errors.push('goto: '+e.message));
    await page.waitForTimeout(2500); // preload

    // 1. menu visible?
    const menu = await page.evaluate(() => {
      const g = window.game;
      if (!g) return { err: 'no game' };
      const active = g.scene.getScenes(true).map(s => s.scene.key);
      const canv = !!g.canvas;
      return { active, canv };
    }).catch(e => ({ err: String(e) }));

    // 2. click Start Run (menu center-ish)
    await page.mouse.click(viewport.width / 2, viewport.height * 0.46);
    await page.waitForTimeout(1500);

    // 3. read game state
    const state1 = await page.evaluate(() => {
      const g = window.game;
      if (!g) return { err: 'no game' };
      const gs = g.scene.getScene('Game');
      if (!gs || !gs.world) return { err: 'no game scene' };
      const player = [...gs.world.query('CTransform','CAI')].find(e => e.getComponent('CAI').type === 'player');
      if (!player) return { err: 'no player entity' };
      const t = player.getComponent('CTransform');
      const ents = gs.world.entities.length;
      const enemies = [...gs.world.query('CTransform','CAI')].filter(e => e.getComponent('CAI').type !== 'player').length;
      const projs = [...gs.world.query('CTransform','CProjectile')].length;
      const paused = gs.world.paused;
      return { px: Math.round(t.x), py: Math.round(t.y), ents, enemies, projs, paused };
    }).catch(e => ({ err: String(e) }));

    // 4. move via input for 1.5s
    if (viewport.width > 700) {
      await page.keyboard.down('d');
      await page.waitForTimeout(1500);
      await page.keyboard.up('d');
    } else {
      // touch joystick drag from (110, h-110) toward +x
      const jx = 110, jy = viewport.height - 110;
      await page.touchscreen.tap(jx, jy);
      await page.waitForTimeout(100);
      const steps = 8;
      for (let i = 1; i <= steps; i++) {
        await page.touchscreen.tap(jx + i * 8, jy);
        await page.waitForTimeout(60);
      }
      await page.waitForTimeout(800);
      await page.touchscreen.tap(viewport.width - 10, 10); // release
    }
    await page.waitForTimeout(500);

    const state2 = await page.evaluate(() => {
      const g = window.game;
      if (!g) return { err: 'no game' };
      const gs = g.scene.getScene('Game');
      if (!gs || !gs.world) return { err: 'no game scene' };
      const player = [...gs.world.query('CTransform','CAI')].find(e => e.getComponent('CAI').type === 'player');
      if (!player) return { err: 'no player' };
      const t = player.getComponent('CTransform');
      return { px: Math.round(t.x), py: Math.round(t.y), paused: gs.world.paused };
    }).catch(e => ({ err: String(e) }));

    await page.screenshot({ path: `screens/${label}-1menu.png` });
    await page.waitForTimeout(2000);
    await page.screenshot({ path: `screens/${label}-2game.png` });

    const step = {};
    results.push({ label, menu, state1, state2, errors, logs: logs.slice(0,8), step });

    await ctx.close();
  }

  require('fs').mkdirSync('screens', { recursive: true });
  await runTest('desktop', { width: 1280, height: 720 });
  await runTest('mobile', { width: 480, height: 900 });

  console.log('RESULTS::' + JSON.stringify(results, null, 2));
  await browser.close();
})();
