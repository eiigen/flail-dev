import Phaser from 'phaser';
import type { System } from '@/ecs/System';
import type { World } from '@/ecs/World';
import { hash } from '@/utils/hash';
import { GameConfig } from '@/GameConfig';
import type { CAI } from '@/components/CAI';
import type { CTransform } from '@/components/CTransform';

export class MapGenSystem implements System {
  name = 'MapGenSystem';
  private seed = 0;
  private generated = new Set<string>();
  private tiles = new Map<string, Phaser.GameObjects.Image>();
  private scene: Phaser.Scene;
  private readonly CHUNK = 8; // tiles per chunk
  private readonly RADIUS = 6; // chunks radius around player

  constructor(scene: Phaser.Scene) {
    this.scene = scene;
  }

  init(world: World): void {
    world.on('map-start', (data: { mapId: string; seed: string }) => {
      this.seed = hash(data.seed + data.mapId);
      this.generated.clear();
      this.tiles.clear();
    });
  }

  update(world: World, _dt: number): void {
    const players = [...world.query('CTransform', 'CAI')]
      .filter((e) => e.getComponent<CAI>('CAI')!.type === 'player');
    if (players.length === 0) return;
    const pt = players[0]!.getComponent<CTransform>('CTransform')!;
    const pcx = Math.floor(pt.x / (this.CHUNK * GameConfig.tileSize));
    const pcy = Math.floor(pt.y / (this.CHUNK * GameConfig.tileSize));

    const frames = ['terrain_stone_horizontal_middle','terrain_stone_horizontal_middle','terrain_stone_horizontal_middle','terrain_stone_cloud_middle','grass_filler_1','grass_filler_2'];
    for (let dx = -this.RADIUS; dx <= this.RADIUS; dx++) {
      for (let dy = -this.RADIUS; dy <= this.RADIUS; dy++) {
        const cx = pcx + dx, cy = pcy + dy;
        const key = `${cx},${cy}`;
        if (this.generated.has(key)) continue;
        this.generated.add(key);
        const hx = Math.abs(hash(`${this.seed}:${cx}:${cy}`));
        const variant = frames[hx % frames.length]!;
        for (let tx = 0; tx < this.CHUNK; tx++) {
          for (let ty = 0; ty < this.CHUNK; ty++) {
            const wx = cx * this.CHUNK + tx;
            const wy = cy * this.CHUNK + ty;
            const f = frames[(hx + tx * 7 + ty * 13) % frames.length]!;
            const img = this.scene.add.image(
              wx * GameConfig.tileSize, wy * GameConfig.tileSize, GameConfig.atlasKey, f
            ).setDepth(0);
            this.tiles.set(`${wx},${wy}`, img);
          }
        }
        void variant;
      }
    }

    // Cull far tiles
    const originX = pcx * this.CHUNK, originY = pcy * this.CHUNK;
    for (const [k, img] of this.tiles) {
      const [wx, wy] = k.split(',').map(Number);
      if (Math.abs(wx - originX) > (this.RADIUS + 1) * this.CHUNK ||
          Math.abs(wy - originY) > (this.RADIUS + 1) * this.CHUNK) {
        img.destroy();
        this.tiles.delete(k);
      }
    }
  }
}
