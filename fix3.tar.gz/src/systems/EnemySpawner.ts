import Phaser from 'phaser';
import type { System } from '@/ecs/System';
import type { World } from '@/ecs/World';
import { CTransform } from '@/components/CTransform';
import { CHealth } from '@/components/CHealth';
import { CAI } from '@/components/CAI';
import { CSprite } from '@/components/CSprite';
import { GameConfig } from '@/GameConfig';
import { hash } from '@/utils/hash';

const ENEMY_TYPES = [
  { frame: 'enemy_slime_normal', hp: 40, speed: 70, name: 'slime_normal' },
  { frame: 'enemy_snail', hp: 60, speed: 45, name: 'snail' },
  { frame: 'enemy_mouse', hp: 25, speed: 120, name: 'mouse' },
  { frame: 'enemy_ladybug', hp: 35, speed: 95, name: 'ladybug' },
  { frame: 'enemy_worm_normal', hp: 55, speed: 60, name: 'worm_normal' },
] as const;

export class EnemySpawner implements System {
  name = 'EnemySpawner';
  private spawnTimer = 0;
  private wave = 0;
  private spawnInterval = 1500;

  constructor(_scene: Phaser.Scene) {}

  init(world: World): void {
    world.on('wave-reached', (data: { wave: number }) => {
      this.wave = data.wave;
      this.spawnInterval = Math.max(400, 1500 - this.wave * 40);
    });
  }

  update(world: World, dt: number): void {
    if (world.paused) return;
    this.spawnTimer += dt;
    if (this.spawnTimer < this.spawnInterval) return;
    this.spawnTimer = 0;

    const player = [...world.query('CTransform', 'CAI')]
      .find((e) => e.getComponent<CAI>('CAI')!.type === 'player');
    if (!player) return;
    const pt = player.getComponent<CTransform>('CTransform')!;

    const count = 1 + Math.min(4, Math.floor(this.wave / 2));
    for (let i = 0; i < count; i++) {
      const type = ENEMY_TYPES[Math.abs(hash(`${this.wave}:${i}:${Date.now()}`)) % ENEMY_TYPES.length]!;
      const angle = Math.random() * Math.PI * 2;
      // ponytail: spawn just outside weapon range (320) so combat engages fast
      const dist = 240 + Math.random() * 120;
      const enemy = world.createEntity();
      enemy.addComponent('CTransform', new CTransform({
        x: pt.x + Math.cos(angle) * dist,
        y: pt.y + Math.sin(angle) * dist,
      }));
      enemy.addComponent('CHealth', new CHealth({ max: type.hp, current: type.hp }));
      enemy.addComponent('CAI', new CAI({ type: 'melee' }));
      enemy.addComponent('CSprite', new CSprite({ frame: type.frame, scale: 2 }));
      (enemy as any).enemyName = type.name;
    }
  }
}
