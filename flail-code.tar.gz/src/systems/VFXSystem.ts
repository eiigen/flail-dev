import Phaser from 'phaser';
import type { System } from '@/ecs/System';
import type { World } from '@/ecs/World';
import type { SettingsManager } from './SettingsManager';

export class VFXSystem implements System {
  name = 'VFXSystem';
  private settings: SettingsManager;
  private scene: Phaser.Scene;

  constructor(scene: Phaser.Scene, settings: SettingsManager) {
    this.scene = scene;
    this.settings = settings;
  }

  init(world: World): void {
    world.on('play-vfx', (data: { type: string; x: number; y: number }) => {
      if (this.settings.get('accessibility').reducedMotion) return;
      if (data.type === 'kill') {
        this.burst(data.x, data.y, 0xffffff, 10, 120);
      } else if (data.type === 'bossRoar') {
        this.burst(data.x, data.y, 0xff2222, 26, 300);
        this.scene.cameras.main.shake(300, 0.008);
      } else {
        this.burst(data.x, data.y, 0xcc88ff, 8, 100);
      }
      this.scene.cameras.main.shake(80, 0.002);
    });
    world.on('screen-shake', (data: { intensity: number; duration: number }) => {
      if (this.settings.get('accessibility').reducedMotion) return;
      this.scene.cameras.main.shake(data.duration, data.intensity / 10000);
    });
  }

  private burst(x: number, y: number, color: number, count: number, speed: number): void {
    const parts = this.scene.add.particles(x, y, GameConfigTexture, {
      speed: { min: speed * 0.4, max: speed },
      scale: { start: 0.5, end: 0 },
      lifespan: { min: 300, max: 700 },
      quantity: count,
      tint: color,
      emitting: false,
    });
    parts.explode(count);
    this.scene.time.delayedCall(800, () => parts.destroy());
  }

  update(_world: World, _dt: number): void {}
}

const GameConfigTexture = 'main';
